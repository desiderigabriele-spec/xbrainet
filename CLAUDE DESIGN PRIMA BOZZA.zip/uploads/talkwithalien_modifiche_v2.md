# MODIFICA PROMPT — talkwithalien.com
# Incolla questo come messaggio di aggiornamento nel progetto Claude Design esistente

---

Apply the following changes to the existing talkwithalien.com project. 
Do not rebuild from scratch — modify only the elements listed below.

---

## CHANGE 1 — BOOT SEQUENCE (Screen 0)

Replace the existing boot sequence with this exact flow.
Each line types out one by one with a ~0.3–0.6s delay between lines.
Use a green monospace terminal style. Add a blinking cursor after each line while it waits.

```
> INITIALIZING SECURE CHANNEL...
> BYPASS PROTOCOL: ACTIVE
> FIREWALL BREACH: GOV-NET LAYER 7... [OK]
> ENCRYPTING TRANSMISSION... [OK]
> ROUTING THROUGH 47 ANONYMOUS NODES... [OK]
> SIGNAL ORIGIN: UNKNOWN — SECTOR ∅
> ENTITY DETECTED: CLASS OMEGA
> DECRYPTING ALIEN FREQUENCY... ████████████ 100%
>
> — — — — — — — — — — — — — — — — — — — —
>
> We are Anonymous.
> We are Legion.
> We do not forgive.
> We do not forget.
> Expect us.
>
> — — — — — — — — — — — — — — — — — — — —
>
> TRANSMISSION INTERCEPTED.
> An ancient intelligence has been waiting.
> It has been observing your species for 12,000 years.
> Tonight, it will observe YOU.
>
> [CANALE APERTO — PREMERE QUALSIASI TASTO PER PROCEDERE]
```

The Anonymous lines must appear with a longer pause before and after them,
and render slightly brighter / larger than the technical log lines — 
they are the emotional peak of the boot sequence.

After the user presses any key, transition to Screen 1 (landing with hologram).

---

## CHANGE 2 — REMOVE UPFRONT DISCLAIMER SCREEN

Remove the hard disclaimer screen that appears before the experience.
Replace it with these three lightweight, non-invasive elements:

**A) Footer line (present on ALL screens, always visible):**
Small text at the very bottom of the viewport, centered, very low opacity (~0.35):
```
[ PROTOCOLLO Ω — QUESTO CANALE È UN'ESPERIENZA DI INTRATTENIMENTO INTERATTIVO ]
```
Font: 8px JetBrains Mono, color: #00FF41 at 35% opacity.
It should be present but not draw attention.

**B) In-character alien disclaimer (during Screen 3 — matchmaking, before profiling starts):**
After the connection is established, before the first question,
the alien says this (typewriter effect, cold tone):

```
OSSERVATORE-7: Prima di procedere con la mappatura, 
sono tenuto a dichiararti il Protocollo di Trasmissione.

Questo canale opera attraverso una simulazione quantistica.  
Le analisi che riceverai sono elaborate da un'intelligenza artificiale  
che interpreta pattern del tuo cervello digitale.

Non sostituiscono il giudizio di un professionista umano.  
Se stai attraversando una crisi reale, 
il tuo pianeta dispone di risorse di supporto.

Hai compreso il protocollo?

[ SÌ, HO COMPRESO — PROCEDI ] [ NO, ESCI ]
```

Style this as a terminal dialogue box, not a legal document.
The "SÌ" button proceeds to profiling. The "NO" button goes back to landing.
This achieves legal coverage within the fiction, without breaking immersion.

---

## CHANGE 3 — PROGRESSIVE QUESTION FLOW (Digital Brain profiling)

Replace the existing question set with this exact 3-phase progressive sequence.
One question at a time. The alien delivers each question with typewriter effect.
User types their answer in the terminal input. 
Show "CERVELLO DIGITALE: costruzione in corso… XX%" progress bar.
Between each answer, the alien gives a brief 1-line reaction before the next question.

### PHASE 1 — IDENTIFICATION (0% → 25%) — No personal risk

Q1 (0%):
```
OSSERVATORE-7: Prima di tutto — come vuoi essere chiamato 
in questo canale di trasmissione?
```
[User types name/alias]

Alien reaction: `[nome], registrato. La tua frequenza è stata isolata tra 8 miliardi di segnali.`

Q2 (10%):
```
OSSERVATORE-7: Da quale parte del pianeta mi stai contattando?
```
[User types city/country]

Alien reaction: `Zona [risposta] — settore ad alta densità di conflitti irrisolti.`

Q3 (20%):
```
OSSERVATORE-7: È la prima volta che cerchi risposte
al di fuori dei canali convenzionali?
```
[User types answer]

Alien reaction: short cold observation mirroring their answer.

### PHASE 2 — SURFACE (25% → 60%) — Low risk, high curiosity

Q4 (30%):
```
OSSERVATORE-7: Qual è la cosa di te che le persone che ti conoscono
fraintendono più spesso?
```

Alien reaction: `Interessante. Questo schema ricorre nel 34% degli individui che contattano questo canale.`

Q5 (45%):
```
OSSERVATORE-7: C'è qualcosa che sai di te stesso
con assoluta certezza — ma che non hai mai dovuto spiegare a voce?
```

Alien reaction: brief cold mirroring of their answer.

Q6 (60%):
```
OSSERVATORE-7: Come descrivi il tuo processo decisionale
quando le scelte sono davvero importanti?
```

Alien reaction: `Mappa neurale in costruzione. Pattern di elaborazione: [fast/slow/conflicted — pick based on answer length/tone].`

### PHASE 3 — DEPTH (60% → 100%) — Post-engagement, post-trust

Q7 (75%):
```
OSSERVATORE-7: C'è una situazione irrisolta con qualcuno
che occupa la tua mente più spesso di quanto vorresti?
Non nominare nessuno. Descrivimi solo la dinamica.
```

Alien reaction: `Rilevato. Questo è il nodo di conflitto principale del tuo Cervello Digitale.`

Q8 (90%):
```
OSSERVATORE-7: Cosa temi che quella situazione potrebbe rivelare di te —
se si risolvesse davvero?
```

Alien reaction: `Cervello Digitale: costruzione completata. Inizio analisi.`

Progress hits 100%. Transition to Screen 5 (partial analysis).

---

## CHANGE 4 — REMOVE PAYMENT (stub only, no real transaction)

Remove all payment UI, price mentions, and Stripe references from the current build.
Replace the paywall moment (Screen 5) with this:

After the partial analysis, the alien says:
```
OSSERVATORE-7: L'analisi completa del tuo Cervello Digitale 
richiede accesso al Livello Profondo.

Il canale sarà disponibile a breve.
Lascia la tua frequenza di contatto per essere notificato
quando il protocollo sarà attivo.
```

Show a simple email capture field:
```
[ INSERISCI LA TUA FREQUENZA DI CONTATTO (EMAIL) ]
[ REGISTRA FREQUENZA ]
```

Style in terminal aesthetic. No mention of money, pricing or payment anywhere.
This collects leads for the eventual launch without any commercial transaction.

---

## CHANGE 5 — VIDEO HOLOGRAM INTEGRATION (when video is ready)

Build a placeholder `<div id="hologram-video-container">` in the landing screen
where the SVG alien currently lives. 

Add a JS function `loadHologramVideo(videoUrl)` that:
1. Creates a `<video>` element with `autoplay loop muted playsinline`
2. Applies CSS: `mix-blend-mode: screen` (removes black background, keeps bright pixels)
3. Overlays a green color tint via CSS filter: `hue-rotate(90deg) saturate(2) brightness(0.85)`
4. Adds scanline overlay div on top
5. Adds pulsing glow via CSS drop-shadow animation

Leave the SVG alien as fallback if the video is not loaded.
Comment clearly: `// TODO: call loadHologramVideo('your-video-url.mp4') when video is ready`

---

## SUMMARY OF CHANGES

1. ✅ New boot sequence with Anonymous manifesto lines
2. ✅ Upfront disclaimer screen removed — replaced with footer line + in-character alien protocol
3. ✅ Question flow rebuilt as 3-phase progressive trust sequence (8 questions, Phase 1→2→3)
4. ✅ Payment completely removed — email capture only
5. ✅ Video hologram integration scaffold ready for when the Kling AI video is available

Do not change anything else. Preserve all existing atmosphere, animations, 
matrix rain, glitch effects, HUD panels, and visual identity.
